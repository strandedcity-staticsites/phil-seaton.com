</div>
<div id="footer">
<p id="copyright">
<!-- &copy; 2011 Phil Seaton -->
</p>
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>