<?php get_header(); ?>


<?php the_post(); ?>


<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<!-- <h1 class="entry-title"><?php the_title(); ?></h1> -->

<div class="entry-content" id="entry-content">
<?php the_content(); ?>
<a href="http://www.phil-seaton.com" rel="address:/"><div class="returnToIndex" rel="slideshow"> INDEX<div style="position:absolute;top:0;left:0;width:100%;height:100%"></div></div></a>
<div class="left-button" rel="slideshow">BACK</div>
<div class="right-button" rel="slideshow">NEXT</div>
<div class="slideControlUnderlay"></div>

<div class="simpleSlideStatus-tray" rel="slideshow">
    <div class="simpleSlideStatus-window" rel="slideshow"></div>
</div>


</div>
</div>

<?php get_footer(); ?>

</body>
</html>