<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta http-equiv="content-type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title>Phil Seaton | Portfolio</title>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" />

<!--BEGIN WP_HEAD() -->
<?php wp_head(); ?>
<!--END WP_HEAD() -->

<!-- Links to custom & plugin javascripts and css -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_url'); ?>/js/jquery.simpleSlide.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php bloginfo("template_url"); ?>/js/mosaic.1.0.1.min.js"></script> 
<script type="text/javascript" src="<?php bloginfo("template_url"); ?>/js/jquery.address-1.4.min.js"></script> 
<script type="text/javascript" src="<?php bloginfo("template_url"); ?>/js/philsjs.js"></script>

<!--add a blank style for each category name:-->
<style>
<?php
$args=array('orderby' => 'name','order' => 'ASC');
$categories=get_categories($args);

foreach($categories as $category) { 
	if ($category->name != 'Uncategorized') {
		echo '.'.$category->name.' {}';
	}
}
echo "\n\n";
?>

</style>

<!-- add jquery code to handle category highlighting-->
<script type="text/javascript">
$(document).ready(function () {        
	
// handle "highlighting" feature -- step 1 is to reduce the opacity of everything to 0.1, then a series of functions exists to bring the opacity back for everything that's currently highlighted.

//-- HANDLING OF GREEN HOVER LABELS ON CATEGORIES WHEN PROJECTS ARE HOVERED -->
<?php
$args=array('orderby' => 'name','order' => 'ASC');
$categories=get_categories($args);

// here's the javascript function needed to handle hovers on the category buttons
//$hoverFunc = <<<EOD
//$(".mosaic-block").hover(	function () {
//	if($(this).is(".interaction") && $("#interaction").is(".allowHover") && $(this).css("opacity") == 1 ) {
//		$("#interaction").find(".rollover").stop().fadeTo(100, 0.5);
//	}},	function () {		
//	if($(this).is(".interaction") && $("#interaction").is(".allowHover")) {
//		$("#interaction").find(".rollover").stop().fadeTo(100, 0);			
//	}
//});
//EOD;

//$stickyYellowFunc = <<<EOD
//$("#fabrication").click( function () {
//	$(".architecture, .energy, .fabrication, .furniture, .geometry, .interaction, .photography, .web, ").fadeTo(200, 0.07).delay(200); 
//	$(".fabrication").fadeTo(200,1);$(".menuitem_container2").addClass("allowHover");
//	$(".menuitem_container2").find(".rollover").stop().fadeTo(200, 0);
//	$(this).find(".rollover").stop().fadeTo(200, 1);
//	$(this).removeClass("allowHover");});
//EOD;

// Handle the reverse-highlight feature where categories turn green to coordinate with mosaic squares
//foreach($categories as $category) { 
//	if ($category->name != 'Uncategorized') {
//		echo '$(".mosaic-block").hover(';
//		echo '	function () {';
//		echo '		if($(this).is(".'.$category->name.'") && $("#'.$category->name.'").is(".allowHover") && $(this).css("opacity") == 1 ) {';
//		echo '			$("#'.$category->name.'").find(".rollover").stop().fadeTo(100, 0.5);	';
//		echo '		}';
//		echo '	},';
//		echo '	function () {';
//		echo '		if($(this).is(".'.$category->name.'") && $("#'.$category->name.'").is(".allowHover")) {';
//		echo '			$("#'.$category->name.'").find(".rollover").stop().fadeTo(100, 0);	';
//		echo '		}';
//		echo '	}';
//		echo ");\n\n";
//	}
//}
?>

	
// End of Jquery code -- leave these brackets in place!
});
</script>

<!-- Deep link handling: -->
<script type="text/javascript"><!--

	/////////////////////////////////////
	// PREP VARIABLES FOR LIQUID LAYOUT
	var projectCount = 5;
	var topPoint = 100;
	var containerHeight = $(window).height()*0.9-topPoint-projectCount*20;
	var windowWidth = $(window).width();
	var lastWH = $(window).height(); // used to track the window height for resizing fluidly



	$(document).ready( function() {
		// prepare ajax:
		$.ajaxSetup({cache:false});
	
		// Event handlers for deep linking
	    $.address.init(function(event) {
			var url = $('[rel=address:' + event.value + ']').attr('href');
			var title = $('[rel=address:' + event.value + ']').attr('title');
			
			if (event.value != '/') { // load content page
				$("#load_post").load(url + " #entry-content", function () {/*content loaded*/resizer();});
				$.address.title( title + ' | Phil Seaton' );
				$("#whole_container").css('left','-100%');
			} else { // for the index page or any mistyped url, load the main page:
				clearPost();
				$("#whole_container").css('left','0%');
			}
	    });
		
	    $.address.change(function(event) {
			var url = $('[rel=address:' + event.value + ']').attr('href');
			var title = $('[rel=address:' + event.value + ']').attr('title');
			
			if (event.value != '/') { // load content page
				$("#load_post").load(url + " #entry-content", function () {/*content loaded*/resizer();});
				$.address.title( title + ' | Phil Seaton' );
				$("#whole_container").animate({left:"-100%"}, 500, function () {/*Animation complete*/;});
			} else { // for the index page or any mistyped url, load the main page:
				//alert("scrolling to home");
				$.address.title( 'Phil Seaton | Portfolio' );
				$("#whole_container").animate({left:"0%"}, 500, function () {/*Animation complete*/;clearPost();});
			}			
	    });
		
		function clearPost() { // removes all of the ajax-loaded content from a particular post or page. Replaces it with the loading graphic
				$('#load_post').html('<div style="position:absolute;top:40px;left:0;width:2000px;height:12px;background-color:#888;"></div><div style="position:absolute;top:60px;left:0;width:2000px;height:12px;background-color:#333;"></div><div id="loadingGif"><img style="position:absolute; top:-70px;left:-50px;" src="<?php bloginfo("template_url"); ?>/img/pageload.gif"></div>');
		}
		
		// prepare simpleslide:
		simpleSlide({
			'fullscreen': 'true', 
			'swipe': 'true', 
			'set_speed': 400, 
			'status_color_outside': '#666', 
			'status_color_inside': '#333',
			'status_width': 100,
		});
		
		function liquid() {
			///////////////////////////////////////////////////////
			// BEGIN CODE DEDICATED TO LIQUID DISPLAY LAYOUT
			projectCount = 5;
			topPoint = 200;
			topPoint = $("#web").parent().offset().top;
			containerHeight = $(window).height()*0.9-topPoint-projectCount*20;
			windowWidth = $(window).width();
			
			//$("#lastrow").css('top',$("#web").parent().offset().top );
			$(".index_container").css({
				'top' : topPoint,
				'height' : containerHeight+projectCount*20,
			});
			$(".crossbar_container").css({
				'height' : containerHeight,
			});
			$(".mainImage").css({
				'height' : containerHeight-28,
				'width' : windowWidth - 350,
			});
			$(".index_textbox").css({
				'height' : containerHeight-28,
				'width' : 250,
				'left' : windowWidth - 332,
			});
			$(".index_project_anchor").css({
				'height' : containerHeight-28,
				'width' : 64,
				'left' : windowWidth - 72,
			});
			$(".index_project_anchor_text").css({
				'margin-top' : (containerHeight-28)/2-20,
			});
			var difference = $(window).height() - lastWH;
			$(".active").css('top',containerHeight);
			lastWH = $(window).height();
			
			$("img").each(function() {
				// calculate aspect ratio of image and parent, then set image prop's based on comparison:
				var $i = $(this); var $c = $i.parent();
				var i_ar = $i.width() / $i.height();
				var c_ar = $c.width() / $c.height();
				if (i_ar > c_ar) { $i.css({'height':'100%','width':'auto'}); }
				else { $i.css({'width':'100%','height':'auto'});  }
				// now center the image:
				//$i.css('left',-($c.width()-$i.width())/2);
			});
			// END LIQUID DISPLAY CODE
			///////////////////////////////////////////	
		}
		
		// make the layout right on load:
		liquid();
		
		// set up a timer to institute resize delay on content side for slide show
		var timer = '';
		$(window).resize( function() {
			liquid();
			clearTimeout(timer);
			timer = setTimeout('resizer()', 300);
		});
		
		window.onorientationchange = function() {
			resizer();
		}

		// HANDLE ANIMATION EFFECTS FOR TITLE BARS
		$(".crossbar_titlebar").click( function () {
			var whichBar = parseInt($(this).attr('id').substring(3))+1; // figure out which bar was clicked
			if ( $("#cont" + whichBar).is(".active") ) {
				$("#cont" + whichBar).removeClass('active');
				// close all the other containers
				$(".crossbar_container").animate({top: 20,}, 400, function() {/* Animation complete.*/}); 
			} else {
				 // close all the other containers
				$(".crossbar_container").not("#cont" + whichBar).animate({top: 20,}, 400, function() {/* Animation complete.*/});
				$(".crossbar_container").not("#cont" + whichBar).removeClass('active');
				// open the clicked container
				$('#cont' + whichBar).animate({top: containerHeight,}, 400, function() { /* Animation complete.*/ }); 
				$("#cont" + whichBar).addClass('active');
			}
		});

		// hover over the project titles. 
		// Includes the "reverse highlight" feature to show which categories a project falls under
		$(".crossbar_titlebar").hover( function () {
				if ( $(this).is('.allowHover') ) {
					$(this).css('background-color','#AAA'); // change the background color of this project's title bar
					
					// The following few lines find the categories that this project falls under
					// and highlights those in the menu bar at top of screen
					var classList =$(this).attr('class').split(/\s+/);
					$.each( classList, function(index, className){
						if (className != 'crossbar_titlebar' && className != 'allowHover') {
							$('#'+className).css({"background":"#51A3E5",color:"#FFF"}); // change color of appopriate categories
						}
					});					
				}
			},
			function () {
				if ( $(this).is('.allowHover') ) {
					$(this).css('background-color','#777');
					
					// The following few lines find the categories that this project falls under
					// and highlights those in the menu bar at top of screen
					var classList =$(this).attr('class').split(/\s+/);
					$.each( classList, function(index, className){
						if (className != 'crossbar_titlebar' && className != 'allowHover') {
							$('#'+className).css({"background":"#777",color:"#000"}); // change color of appopriate categories
						}
					});					
				}
		});
		
		// hover over anchors for next project
		$(".index_project_anchor").hover( function () {
				$(this).css('background-color','#DDD');
			},
			function () {
				$(this).css({'background-color':'#FFF'});
		});
		
		// HIGHLIGHT PROJECT TITLE BARS when the corresponding category label is clicked
		$(".menuitem_container2").click( function (event) {
			$(".menuitem_container2").css({"background":"#777",color:"#000"});// return all category buttons to grey
			$(this).css({"background":"#51A3E5",color:"#FFF"});// change the CLICKED category button to BLUE
			$(".menuitem_container2").addClass('allowHover'); // add hover behavior to all category labels
			$(this).removeClass('allowHover'); // remove hover activity from the CLICKED category label only
			
			
			var categoryClicked = $(this).attr('id');
			$('.crossbar_titlebar').not('.'+categoryClicked).css({"background":"#777",color:"#FFF"}); // return all title bars to regular grey
			$('.crossbar_titlebar').not('.'+categoryClicked).addClass('allowHover'); // re-enable hover activity for non-selected titlebars
			
			$('.'+categoryClicked).css({"background":"#51A3E5",color:"#333"}); // make the background of highlighted projects colored
			$('.'+categoryClicked).removeClass('allowHover'); // prevent it from changing during hover
		});

		$(".menuitem_container2").hover( function () {
				if ( $(this).is('.allowHover') ) {$(this).css({"background":"#51A3E5",color:"#FFF"});};
		}, function () {
				if ( $(this).is('.allowHover') ) {$(this).css({"background":"#777",color:"#000"});};
		});
		
		// handle rollovers for permanent pages (bio, contact, etc)
		$(".rollover_magenta").css({'opacity':'0'});
		$('.menuitem_container').hover(
			function() {
				$(this).find('.rollover_magenta').stop().fadeTo(200, 1);
			},
			function() {
				$(this).find('.rollover_magenta').stop().fadeTo(200, 0);
			}
		)
		

	
		//////////////////////////
		// MUST WAIT FOR IMAGES TO LOAD BEFORE QUERYING THEIR SIZE
		// this function proportionately sizes images to FULLY fill their container
		$("img").load(function() {
			// calculate aspect ratio of image and parent, then set image prop's based on comparison:
			var $i = $(this); var $c = $i.parent();
			var i_ar = $i.width() / $i.height();
			var c_ar = $c.width() / $c.height();
			if (i_ar > c_ar) { $i.css({'height':'100%','width':'auto'}); }
			else { $i.css({'width':'100%','height':'auto'});  }
			// now center the image:
			//$i.css('left',-($c.width()-$i.width())/2);
		});

	////////////////////////////////////////
	// END JQUERY SECTION
	});
	
	/////////////////////////////////
	// RESIZE FUNCTION -- NOTE THIS IS NOT A JQUERY FUNCTION!
	function resizer() { // handles the re-layout of the content pages when the user resizes his screen
		var agent = navigator.userAgent.toLowerCase();
		var is_iphone = ((agent.indexOf('iphone') != -1));
		var is_ipad = ((agent.indexOf('ipad') != -1));
		var is_msie = ((agent.indexOf('msie') != -1));
//		if(is_iphone || is_ipad || is_msie){
// 			NOTE THAT THIS FUNCTION IS REQUIRED TO MAKE THE PAGE RESIZE CORRECTLY IN IE WHEN IT IS **NOT** LOADED THROUGH AJAX!			
// 			location.reload(true); // reload the whole page if it's not in an iframe at all
//		} else {					
			simpleSlide({
				'fullscreen': 'true', 
				'swipe': 'true', 
				'set_speed': 400, 
				'status_color_outside': '#666', 
				'status_color_inside': '#333',
				'status_width': 100,
				'callback': function(){
					// whenever the window is resized, be sure that the status bar is reset to 0.
					// a bug in simpleslide prevented the reset, causing the bar to just keep counting
					// even though the slider position was reset.
					$('.simpleSlideStatus-window').css('marginLeft', '0px');
					$('.caption-tray').css('marginLeft', '0px');
				}
			});
//		};
	}
	
// --></script>

</head>
<body>
