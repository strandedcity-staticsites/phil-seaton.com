<?php

add_theme_support( 'post-thumbnails' );

set_post_thumbnail_size( 250, 250, true );

add_action('after_setup_theme','bw_images_size');
function bw_images_size() {
	$crop = get_option('thumbnail_crop')==1 ? true : false;
	add_image_size('thumbnail-bw', 250,250, $crop);
}

// This theme uses Featured Images (also known as post thumbnails) for per-post/per-page Custom Header images


function bw_images_filter($meta) {
	$file = wp_upload_dir();
 
	// Need to check to see if their was even a generated 'thumb-m' in case the image uploaded was the appropriate size
	// and therefore will be used in it's largest form
	if (isset($meta['sizes']['thumbnail-bw'])) {
		$file = trailingslashit($file['path']).$meta['sizes']['thumbnail-bw']['file'];
 
	// The thumbnail didn't get created because the uploaded image was the correct size before scaling / cropping.
	// Need to get base directory instead of path here because the original file already has the year/month structure in it's file attribute.
	} else {
		$file = trailingslashit($file['basedir']).$meta['file'];
		$explodedPath = explode("/", $meta['file']);
 
		// Manually insert the thumbnail-bw that didn't get created upon upload and append '-bw' to the filename
		$explodedFileName = explode(".", $exploded[2]);
		$updatedFileName = $explodedFileName[0] . '-bw.' . $explodedFileName[1];
		$meta['sizes']['thumbnail-bw']['file'] = $updatedFileName;
		$meta['sizes']['thumbnail-bw']['width'] = 188; // Set these dimensions to match the dimensions for the add_image_size above
		$meta['sizes']['thumbnail-bw']['height'] = 188;
	}
 
	list($orig_w, $orig_h, $orig_type) = @getimagesize($file);
	$image = wp_load_image($file);
 
	imagefilter($image, IMG_FILTER_GRAYSCALE);
	//imagefilter($image, IMG_FILTER_GAUSSIAN_BLUR);
	switch ($orig_type) {
		case IMAGETYPE_GIF:
			$file = str_replace(".gif", "-bw.gif", $file);
			imagegif($image, $file);
			break;
		case IMAGETYPE_PNG:
			$file = str_replace(".png", "-bw.png", $file);
			imagepng($image, $file);
			break;
		case IMAGETYPE_JPEG:
			$file = str_replace(".jpg", "-bw.jpg", $file);
			imagejpeg($image, $file);
			break;
	}
 
	return $meta;
}
add_filter('wp_generate_attachment_metadata','bw_images_filter');




load_theme_textdomain( 'philseaton', TEMPLATEPATH . '/languages' );
$locale = get_locale();
$locale_file = TEMPLATEPATH . "/languages/$locale.php";
if ( is_readable($locale_file) )
require_once($locale_file);
function get_page_number() {
if (get_query_var('paged')) {
print ' | ' . __( 'Page ' , 'philseaton') . get_query_var('paged');
}
}
add_action( 'after_setup_theme', 'philseaton_theme_setup' );
function philseaton_theme_setup() {
add_theme_support( 'automatic-feed-links' );
}
if ( ! isset( $content_width ) ) $content_width = 640;
add_filter('the_title', 'philseaton_title');
function philseaton_title($title) {
if ($title == '') {
return 'Untitled';
} else {
return $title;
}
}
function register_my_menus() {
register_nav_menus(
array( 'main-menu' => __( 'Main Menu' ))
);
}
add_action( 'init', 'register_my_menus' );
function theme_widgets_init() {
register_sidebar( array (
'name' => 'Primary Widget Area',
'id' => 'primary-widget-area',
'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
'after_widget' => "</li>",
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
}
add_action( 'init', 'theme_widgets_init' );
$preset_widgets = array (
'primary-aside'  => array( 'search', 'pages', 'categories', 'archives' ),
);
if ( isset( $_GET['activated'] ) ) {
update_option( 'sidebars_widgets', $preset_widgets );
}
function catz($glue) {
$current_cat = single_cat_title( '', false );
$separator = "\n";
$cats = explode( $separator, get_the_category_list($separator) );
foreach ( $cats as $i => $str ) {
if ( strstr( $str, ">$current_cat<" ) ) {
unset($cats[$i]);
break;
}
}
if ( empty($cats) )
return false;
return trim(join( $glue, $cats ));
}
function tag_ur_it($glue) {
$current_tag = single_tag_title( '', '',  false );
$separator = "\n";
$tags = explode( $separator, get_the_tag_list( "", "$separator", "" ) );
foreach ( $tags as $i => $str ) {
if ( strstr( $str, ">$current_tag<" ) ) {
unset($tags[$i]);
break;
}
}
if ( empty($tags) )
return false;
return trim(join( $glue, $tags ));
}
function commenter_link() {
$commenter = get_comment_author_link();
if ( ereg( '<a[^>]* class=[^>]+>', $commenter ) ) {
$commenter = preg_replace( '/(<a[^>]* class=[\'"]?)/', '\\1url ' , $commenter );
} else {
$commenter = preg_replace( '/(<a )/', '\\1class="url "' , $commenter );
}
$avatar_email = get_comment_author_email();
$avatar = str_replace( "class='avatar", "class='photo avatar", get_avatar( $avatar_email, 80 ) );
echo $avatar . ' <span class="fn n">' . $commenter . '</span>';
}
function custom_comments($comment, $args, $depth) {
$GLOBALS['comment'] = $comment;
$GLOBALS['comment_depth'] = $depth;
?>
<li id="comment-<?php comment_ID() ?>" <?php comment_class() ?>>
<div class="comment-author vcard"><?php commenter_link() ?></div>
<div class="comment-meta"><?php printf(__('Posted %1$s at %2$s <span class="meta-sep"> | </span> <a href="%3$s" title="Permalink to this comment">Permalink</a>', 'philseaton'),
get_comment_date(),
get_comment_time(),
'#comment-' . get_comment_ID() );
edit_comment_link(__('Edit', 'philseaton'), ' <span class="meta-sep"> | </span> <span class="edit-link">', '</span>'); ?></div>
<?php if ($comment->comment_approved == '0') _e("\t\t\t\t\t<span class='unapproved'>Your comment is awaiting moderation.</span>\n", 'philseaton') ?>
<div class="comment-content">
<?php comment_text() ?>
</div>
<?php
if($args['type'] == 'all' || get_comment_type() == 'comment') :
comment_reply_link(array_merge($args, array(
'reply_text' => __('Reply','philseaton'),
'login_text' => __('Log in to reply.','philseaton'),
'depth' => $depth,
'before' => '<div class="comment-reply-link">',
'after' => '</div>'
)));
endif;
?>
<?php }
function custom_pings($comment, $args, $depth) {
$GLOBALS['comment'] = $comment;
?>
<li id="comment-<?php comment_ID() ?>" <?php comment_class() ?>>
<div class="comment-author"><?php printf(__('By %1$s on %2$s at %3$s', 'philseaton'),
get_comment_author_link(),
get_comment_date(),
get_comment_time() );
edit_comment_link(__('Edit', 'philseaton'), ' <span class="meta-sep"> | </span> <span class="edit-link">', '</span>'); ?></div>
<?php if ($comment->comment_approved == '0') _e('\t\t\t\t\t<span class="unapproved">Your trackback is awaiting moderation.</span>\n', 'philseaton') ?>
<div class="comment-content">
<?php comment_text() ?>
</div>
<?php }