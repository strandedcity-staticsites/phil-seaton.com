<div id="sidebar" class="sidebar">

<!-- BEGIN "PAGES" MENU TO PERMANENT PAGES, SUCH AS BIO AND CONTACTS -->
<div class="sidebar-row" style="background-color: #000;">
<?php 
  $pages = get_pages(); 
  foreach ( $pages as $pagg ) {
	echo '<div class="menuitem_bg" style="width:150px;background-color: #000;">';
  	echo $pagg->post_title;
	echo '<a href="';
	echo get_page_link( $pagg->ID );
	echo '" rel=\'address:/';
	echo $pagg->post_title;
	echo '\' title="';
	echo $pagg->post_title;
	echo '"><div class="menuitem_container"  style="width:150px;background-color: #000;" id="'.$pagg->post_title.'">';
  	//echo $pagg->post_title;
	echo '<div class="rollover_magenta"></div><div class="menuitem_text permpage">';
  	echo $pagg->post_title;
	echo '  ››</div></div></a></div>';
  }
?> 
</div>
<div class="sidebar-row">
<div class="menuitem_bg highlightlink">highlight →</div>

<!-- BEFORE THE LIST OF CATEGORIES, THERE'S A SPECIAL BUTTON TO SHOW ALL PROJECTS -->
<div class="menuitem_bg">none<a href="javascript:void();"><div class="menuitem_container2 allowHover" id="all" style="background:#51A3E5;"><div class="menuitem_text">none ››</div></div></a></div>



<!-- BEGIN "CATEGORIES" MENU SO PEOPLE CAN CLICK TO HIGHLIGHT PROJECTS -->
<?php
$args=array('orderby' => 'name','order' => 'ASC');
$categories=get_categories($args);
foreach($categories as $category) { 
	if ($category->name != 'Uncategorized') {
		echo '';
		echo '<div class="menuitem_bg">';
		echo $category->name;
		echo '<a href="javascript:void();"><div class="menuitem_container2 allowHover" id="';
		echo $category->name;
//		echo '"><div class="rollover"></div><div class="menuitem_text">';
		echo '"><div class="menuitem_text">';
		echo $category->name;
		echo '  ››</div></div></a></div>';
		echo "\n\n";
	}
}
?>
</div>
</div>