<?php get_header(); ?>

<div id="whole_container">
<div id="container">
<?php get_sidebar(); ?>

<!-- <div id="content">  -->

<!-- BEGINNING OF THE LOOP  -->

<div class="index_container">
<?php 
$proj_count = 0;
while ( have_posts() ) : the_post();


// Retrieve categories for each thumbnail, to be used in descriptions and later as a part of the highlighting mechanism
$post_categories = wp_get_post_categories( get_the_ID() );
$cats = array(); $project_categories = "";
foreach($post_categories as $c){
	$cat = get_category( $c );
	$project_categories = $project_categories.' '.$cat->name;
}

// Just for cleanliness of code, I'll define the HTML to be used for each project's display in
// one variable and then do substitutions below:
$projectHTML = <<<EOD

<div class="crossbar_container" id="cont{PROJECTNUMBER}">
	<div class="crossbar_titlebar allowHover{CATEGORIES}" id="bar{PROJECTNUMBER}">
		<div style="margin-top:-1px;">{PROJECT-TITLE}</div>
	</div>
	<div class="mainImage">
		{THUMBNAIL}
	</div>
	<div class="index_textbox">
		<div class="index_text"><span class="index_textbox_title">{PROJECT-TITLE}</span><br /><br />{PROJECT-DESCRIPTION}</div>
	</div>
	<a href="{PERMALINK}" rel='address:/{PERMALINKBASENAME}'>
		<div class="index_project_anchor">
			<div class="index_project_anchor_text">»</div>
		</div>
	</a>
EOD;

// Make substitutions:
$projectHTML = str_replace('{PROJECTNUMBER}', $proj_count, $projectHTML);
$projectHTML = str_replace('{THUMBNAIL}', get_the_post_thumbnail(get_the_ID()), $projectHTML);
$projectHTML = str_replace('{PERMALINK}', get_permalink(), $projectHTML);
$projectHTML = str_replace('{PERMALINKBASENAME}', basename(get_permalink()), $projectHTML);
$projectHTML = str_replace('{PROJECT-TITLE}', get_the_title(), $projectHTML);
$projectHTML = str_replace('{PROJECT-DESCRIPTION}', get_the_excerpt(), $projectHTML);
$projectHTML = str_replace('{CATEGORIES}', $project_categories, $projectHTML);

if(function_exists('has_post_thumbnail') && has_post_thumbnail()) {
	$proj_count++;	
	echo $projectHTML;
}


////////////////// DO NOT FORGET!
/////////////////// all of the nested DIVs need to be closed and
/////////////////// the total number of projects needs to be passed to javascript somehow
endwhile; 

// make a bottom bar, just for aesthetics:
echo '<div class="crossbar_container" id="cont'.$proj_count.'"><div class="crossbar_titlebar"></div></div>';

// close all the open nested divs
for ($k = 1; $k <= $proj_count; $k++) {
    echo '</div>';
}


?>
</div>
<!--  END OF THE LOOP-->



<!-- </div>end content-->

<!-- <p id="copyright">
&copy; 2011 Phil Seaton
</p> -->

<!--end container--></div>

<div id="load_post" name="load_post" class="load_post">
<div style="position:absolute;top:40px;left:0;width:2000px;height:12px;background-color:#888;"></div>
<div style="position:absolute;top:60px;left:0;width:2000px;height:12px;background-color:#333;"></div>
<div id="loadingGif">
<img style="position:absolute; top:-70px;left:-50px;" src="<?php bloginfo("template_url"); ?>/img/pageload.gif">
</div>
</div>

</div>
<div class="clearfix"></div>

</body>
</html>