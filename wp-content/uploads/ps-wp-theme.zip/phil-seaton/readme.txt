YOU MAY DELETE THIS FILE AND ANY OTHER FILE(S) BEFORE STARTING YOUR PROJECT

- - THEME - -

philseaton 1.7 WordPress Theme | Demo: http://tidythemes.com/philseaton/

- - DESCRIPTION - -

This theme is aimed at web professionials, but is of course available and supported for anyone.

The bare essentials of a WordPress theme, no CSS styles added. 
Perfect for those who would like to build their own theme from scratch.

One custom menu and one widgetized sidebar to get you started.

If you'd like a jumpstart with CSS and more custom menus and widgetized areas; checkout SuperSimple:
http://tidythemes.com/supersimple/

- - LICENSE - -

Technical Stuff: GNU General Public License v2.0 | http://www.gnu.org/licenses/gpl-2.0.html

Friendly Stuff:
philseaton is 100% free and open source; 
perfect to build your own themes or use as a base for client projects. 
You may share this or list this theme anywhere as long as credit is given.

- - SUPPORT - -

http://tidythemes.com/forum/

Enjoy. Thanks, TidyThemes | http://tidythemes.com/